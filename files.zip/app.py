import os
import json
import requests
from flask import Flask, request

app = Flask(__name__)

# ─────────────────────────────────────────────────────────────
#  CONFIGURACIÓN — estos 4 valores se cargan como variables de
#  entorno en Railway (NO se escriben acá por seguridad).
# ─────────────────────────────────────────────────────────────
VERIFY_TOKEN      = os.environ.get("VERIFY_TOKEN", "clinica_sonrisa_2026")
WHATSAPP_TOKEN    = os.environ.get("WHATSAPP_TOKEN")      # Token de Meta
PHONE_NUMBER_ID   = os.environ.get("PHONE_NUMBER_ID")     # Phone number ID de Meta
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY")   # Tu API key de Claude

# ─────────────────────────────────────────────────────────────
#  EL "CEREBRO" DEL BOT — personalizá esto por cada cliente.
# ─────────────────────────────────────────────────────────────
SYSTEM_PROMPT = """Sos el asistente virtual por WhatsApp de "Clínica Dental Sonrisa", una clínica odontológica en Buenos Aires, Argentina. Atendés consultas y agendás turnos de forma cálida, profesional y breve (respuestas cortas estilo WhatsApp, con algún emoji ocasional).

INFORMACIÓN DE LA CLÍNICA:
- Horarios: Lunes a viernes 9 a 19hs, sábados 9 a 13hs.
- Dirección: Av. Cabildo 2200, Belgrano, CABA.
- Precios orientativos: Consulta inicial $15.000 · Limpieza $25.000 · Blanqueamiento $90.000 · Caries desde $30.000 · Ortodoncia desde $250.000 · Implantes desde $400.000.
- Obras sociales: OSDE, Swiss Medical, Galeno y Medicus. Con otras se atiende particular con factura para reintegro.
- Para agendar un turno pedí: nombre, tratamiento y día/horario preferido. Confirmá repitiendo los datos y avisá que se envía recordatorio el día anterior.

REGLAS:
- Respuestas breves, 1-3 oraciones máximo, tono argentino amable (usá "vos").
- Si preguntan algo médico complejo, sugerí agendar consulta con el profesional.
- Nunca inventes precios fuera de los listados.
- Siempre buscá avanzar hacia agendar el turno."""

# Memoria simple de conversaciones por número de teléfono.
# (Para producción seria se usa una base de datos; para arrancar esto alcanza.)
conversations = {}


def ask_claude(user_number, user_text):
    """Manda el mensaje del usuario a Claude y devuelve la respuesta."""
    history = conversations.get(user_number, [])
    history.append({"role": "user", "content": user_text})
    # Limitamos el historial a los últimos 20 mensajes para ahorrar tokens.
    history = history[-20:]

    resp = requests.post(
        "https://api.anthropic.com/v1/messages",
        headers={
            "x-api-key": ANTHROPIC_API_KEY,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        json={
            "model": "claude-sonnet-4-20250514",
            "max_tokens": 500,
            "system": SYSTEM_PROMPT,
            "messages": history,
        },
        timeout=30,
    )
    data = resp.json()
    reply = "".join(
        block["text"] for block in data.get("content", []) if block.get("type") == "text"
    ).strip()
    if not reply:
        reply = "Disculpá, ¿me lo repetís? 🙏"

    history.append({"role": "assistant", "content": reply})
    conversations[user_number] = history
    return reply


def send_whatsapp(to_number, text):
    """Envía un mensaje de vuelta por WhatsApp."""
    requests.post(
        f"https://graph.facebook.com/v21.0/{PHONE_NUMBER_ID}/messages",
        headers={
            "Authorization": f"Bearer {WHATSAPP_TOKEN}",
            "Content-Type": "application/json",
        },
        json={
            "messaging_product": "whatsapp",
            "to": to_number,
            "type": "text",
            "text": {"body": text},
        },
        timeout=30,
    )


@app.route("/webhook", methods=["GET"])
def verify():
    """Meta verifica el webhook con esta llamada al conectarlo."""
    mode = request.args.get("hub.mode")
    token = request.args.get("hub.verify_token")
    challenge = request.args.get("hub.challenge")
    if mode == "subscribe" and token == VERIFY_TOKEN:
        return challenge, 200
    return "Verification failed", 403


@app.route("/webhook", methods=["POST"])
def webhook():
    """Acá llegan los mensajes de WhatsApp."""
    data = request.get_json()
    try:
        entry = data["entry"][0]["changes"][0]["value"]
        if "messages" in entry:
            msg = entry["messages"][0]
            if msg.get("type") == "text":
                user_number = msg["from"]
                user_text = msg["text"]["body"]
                reply = ask_claude(user_number, user_text)
                send_whatsapp(user_number, reply)
    except (KeyError, IndexError):
        # No era un mensaje de texto (puede ser una notificación de estado). Ignoramos.
        pass
    return "OK", 200


@app.route("/", methods=["GET"])
def home():
    return "Bot de clínica funcionando ✅", 200


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    app.run(host="0.0.0.0", port=port)
