# Bot de WhatsApp para Clínicas — Guía de instalación

Este es el código completo del chatbot. Conecta WhatsApp (Meta Cloud API) con
Claude API. Cuando un paciente escribe por WhatsApp, el bot responde solo.

## Archivos
- `app.py` → el código del bot (no hace falta tocar nada salvo el "cerebro")
- `requirements.txt` → las librerías que necesita
- `Procfile` → le dice a Railway cómo arrancar

## Los 4 datos que vas a cargar en Railway (Variables de entorno)

NO se escriben en el código. Se cargan en Railway → pestaña "Variables".

| Variable | De dónde sale |
|---|---|
| `WHATSAPP_TOKEN` | Meta → WhatsApp → API Setup → "Temporary access token" |
| `PHONE_NUMBER_ID` | Meta → WhatsApp → API Setup → "Phone number ID" |
| `ANTHROPIC_API_KEY` | console.anthropic.com → API Keys → Create Key |
| `VERIFY_TOKEN` | Lo inventás vos (ej: clinica_sonrisa_2026). Lo usás en Meta al conectar el webhook. |

## Pasos para desplegar en Railway

1. Entrá a railway.app y creá cuenta (con GitHub o email).
2. "New Project" → "Deploy from GitHub repo" o "Empty Project".
3. Subí estos 3 archivos (o conectá un repo de GitHub con ellos).
4. Andá a "Variables" y cargá los 4 valores de la tabla de arriba.
5. Railway te da una URL pública (ej: https://tu-bot.up.railway.app).
6. Tu webhook para Meta es esa URL + /webhook
   (ej: https://tu-bot.up.railway.app/webhook)

## Conectar el webhook en Meta

1. Meta → WhatsApp → Configuration → Webhook → "Edit".
2. Callback URL: tu URL de Railway + /webhook
3. Verify token: el mismo VERIFY_TOKEN que pusiste en Railway.
4. Suscribite al campo "messages".
5. Listo. Mandá un WhatsApp al número de prueba y el bot responde.

## Personalizar por cliente

Para cada clínica nueva, solo cambiás el texto de SYSTEM_PROMPT en app.py
(precios, dirección, horarios, obras sociales). Nada más.
